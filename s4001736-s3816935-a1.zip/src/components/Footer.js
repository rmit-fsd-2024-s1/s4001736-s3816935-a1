import React from "react";

export default function Footer() {
  return (
    <footer >
        <p>SOIL &copy; 2024</p>
    </footer>
  );
}


